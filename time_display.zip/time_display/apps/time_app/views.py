from django.shortcuts import render, HttpResponse
from time import gmtime, strftime
import datetime

def index(request):
    currentDT = datetime.datetime.now()
    context = {
        'time': currentDT.strftime("%Y-%m-%d %H:%M%p")
        }
    return render(request, "time_app/index.html", context)

def display(request):
    return redirect("/")


